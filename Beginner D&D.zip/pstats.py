from istats import *
from dice import *


if they choose to add strength 
  s = strength + num
  d = dexterity
  i = intelligence


if they choose to add dexterity
  s = strength 
  d = dexterity + num
  i = intelligence  


if they choose to add intelligence 
  s = strength 
  d = dexterity 
  i = intelligence + num


return s,d,i